from ultralytics import RTDETR

# Load model
model = RTDETR("./ultralytics/cfg/models/ARISNet.yaml")

# Train model
results = model.train(
data="./AFBirds/data.yaml",
epochs=200,
batch=16,
imgsz=640,
workers=8,
device=[0,1]
)

