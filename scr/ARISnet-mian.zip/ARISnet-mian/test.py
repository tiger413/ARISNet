from ultralytics import RTDETR

model = RTDETR("./best.pt")

metrics = model.val(
    data="./ARISNet/data.yaml",      
    split='test',          
    imgsz=640,
    batch=128        
)
