import torch
import torch.nn as nn
 
 
class AJRA_C(nn.Module):
    def __init__(self, in_planes, ratio=4, flag=True):
        super(ChannelAttention_HSFPN, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
 
        self.conv1 = nn.Conv2d(in_planes, in_planes // ratio, 1, bias=False)
        self.relu = nn.ReLU()
        self.conv2 = nn.Conv2d(in_planes // ratio, in_planes, 1, bias=False)
        self.flag = flag
        self.sigmoid = nn.Sigmoid()
 
        nn.init.xavier_uniform_(self.conv1.weight)
        nn.init.xavier_uniform_(self.conv2.weight)
 
    def forward(self, x):
        avg_out = self.conv2(self.relu(self.conv1(self.avg_pool(x))))
        max_out = self.conv2(self.relu(self.conv1(self.max_pool(x))))
        out = avg_out + max_out
        return self.sigmoid(out) * x if self.flag else self.sigmoid(out)

class AJRA_J(nn.Module):

    def __init__(self, dim, ratio=4, flag=True):
        super().__init__()
        self.flag = flag
        self.dim = dim
        
        
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.channel_mlp = nn.Sequential(
            nn.Conv2d(dim, dim // ratio, 1, bias=False),
            nn.ReLU(),
            nn.Conv2d(dim // ratio, dim, 1, bias=False)
        )
        
      
        self.spatial_conv = nn.Conv2d(2, 1, 7, padding=3, bias=False)
        self.spatial_bn = nn.BatchNorm2d(1)
        self.sigmoid = nn.Sigmoid()
        
      
        nn.init.xavier_uniform_(self.channel_mlp[0].weight)
        nn.init.xavier_uniform_(self.channel_mlp[2].weight)
        nn.init.xavier_uniform_(self.spatial_conv.weight)

class Multiply(nn.Module):
    def __init__(self) -> None:
        super().__init__()
 
    def forward(self, x):
        return x[0] * x[1]
 
 
class Add(nn.Module):
    def __init__(self):
        super().__init__()
 
    def forward(self, x):
        return torch.sum(torch.stack(x, dim=0), dim=0)

